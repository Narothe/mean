import { TextFormatDirective } from './text-format.directive';

describe('TextFormatDirective', () => {
  it('should create an instance', () => {
    const directive = new TextFormatDirective();
    expect(directive).toBeTruthy();
  });
});
